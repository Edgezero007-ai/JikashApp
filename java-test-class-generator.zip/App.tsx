
import React, { useState, useCallback } from 'react';
import { GoogleGenAI } from "@google/genai";
import { REQUIREMENTS_TEXT, APP_TITLE, GEMINI_MODEL_NAME } from './constants';
import { Header } from './components/Header';
import { RequirementDisplay } from './components/RequirementDisplay';
import { CodeOutput } from './components/CodeOutput';
import { LoadingSpinner } from './components/LoadingSpinner';
import { ErrorMessage } from './components/ErrorMessage';
import { ActionButton } from './components/ActionButton';
import { Footer } from './components/Footer';

const App: React.FC = () => {
  const [generatedCode, setGeneratedCode] = useState<string>('');
  const [isLoading, setIsLoading] = useState<boolean>(false);
  const [error, setError] = useState<string | null>(null);

  const generateJavaTests = useCallback(async () => {
    setIsLoading(true);
    setError(null);
    setGeneratedCode('');

    if (!process.env.API_KEY) {
      setError("API_KEY environment variable not set. Please configure it before running the application.");
      setIsLoading(false);
      return;
    }

    const ai = new GoogleGenAI({ apiKey: process.env.API_KEY });

    const prompt = `
You are an expert Java (version 11+) programmer specializing in writing comprehensive and runnable unit tests using JUnit 5 (Jupiter).
Based on the following requirements for a project named 'GcashApp', generate complete Java test classes.
Assume necessary domain classes (e.g., User, Account, Transaction) exist with appropriate fields and methods, but you do not need to define them. Focus solely on the test classes.
For database interactions, assume mockable service layers (e.g., UserService, AccountService, TransactionService) are available and can be injected or mocked. Use Mockito for mocking if needed.
Ensure each test class is in its own block, clearly named (e.g., UserAuthenticationTests.java), and includes necessary imports.
The generated test methods should be practical and demonstrate the testing logic clearly.

Requirements:
${REQUIREMENTS_TEXT}

Provide the Java code for each test class. Each class should be compilable and its tests runnable given appropriate mock setup.
Start each Java file content with a comment like "// --- FileName.java ---" followed by the code.
For example:
// --- UserAuthenticationTests.java ---
package com.gcashapp.tests;

import org.junit.jupiter.api.Test;
// ... other imports

public class UserAuthenticationTests {
    // ... test methods
}
// --- End of UserAuthenticationTests.java ---

// --- CheckBalanceTests.java ---
package com.gcashapp.tests;
// ...
// --- End of CheckBalanceTests.java ---

And so on for all required test classes.
Use standard Java conventions and JUnit 5 annotations (e.g., @Test, @BeforeEach, @Mock, @InjectMocks if using Mockito).
Make sure to include package declarations like 'com.gcashapp.tests;'.
    `;

    try {
      const response = await ai.models.generateContent({
        model: GEMINI_MODEL_NAME,
        contents: prompt,
      });
      setGeneratedCode(response.text);
    } catch (e: any) {
      console.error("Error generating Java tests:", e);
      setError(`Failed to generate Java tests: ${e.message || 'Unknown error'}. Check console for details.`);
    } finally {
      setIsLoading(false);
    }
  }, []);

  return (
    <div className="min-h-screen flex flex-col bg-gray-900 text-gray-100 font-sans">
      <Header title={APP_TITLE} />
      <main className="flex-grow container mx-auto px-4 py-8 max-w-7xl">
        <div className="grid grid-cols-1 md:grid-cols-2 gap-8">
          <div className="bg-gray-800 p-6 rounded-lg shadow-xl">
            <h2 className="text-2xl font-semibold mb-4 text-sky-400">Test Requirements</h2>
            <RequirementDisplay requirements={REQUIREMENTS_TEXT} />
            <div className="mt-6 text-center">
              <ActionButton onClick={generateJavaTests} disabled={isLoading}>
                {isLoading ? (
                  <>
                    <LoadingSpinner small />
                    Generating Tests...
                  </>
                ) : (
                  'Generate Java Test Classes'
                )}
              </ActionButton>
            </div>
          </div>
          
          <div className="bg-gray-800 p-6 rounded-lg shadow-xl flex flex-col">
            <h2 className="text-2xl font-semibold mb-4 text-sky-400">Generated Java Code</h2>
            {isLoading && !generatedCode && (
              <div className="flex-grow flex items-center justify-center">
                <LoadingSpinner />
              </div>
            )}
            {error && <ErrorMessage message={error} />}
            {!isLoading && !error && !generatedCode && (
              <div className="flex-grow flex items-center justify-center text-gray-500">
                <p>Click "Generate Java Test Classes" to see the output here.</p>
              </div>
            )}
            {generatedCode && <CodeOutput code={generatedCode} />}
          </div>
        </div>
      </main>
      <Footer />
    </div>
  );
};

export default App;
    