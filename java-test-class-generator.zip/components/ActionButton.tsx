
import React from 'react';

interface ActionButtonProps extends React.ButtonHTMLAttributes<HTMLButtonElement> {
  children: React.ReactNode;
}

export const ActionButton: React.FC<ActionButtonProps> = ({ children, ...props }) => {
  return (
    <button
      {...props}
      className={`
        bg-sky-500 hover:bg-sky-600 text-white font-bold py-3 px-6 rounded-lg 
        transition-all duration-150 ease-in-out transform hover:scale-105
        focus:outline-none focus:ring-2 focus:ring-sky-400 focus:ring-opacity-75
        disabled:bg-gray-600 disabled:cursor-not-allowed disabled:transform-none
        flex items-center justify-center space-x-2
        shadow-lg
        ${props.className || ''}
      `}
    >
      {children}
    </button>
  );
};
    