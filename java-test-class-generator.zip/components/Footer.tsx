
import React from 'react';

export const Footer: React.FC = () => {
  return (
    <footer className="bg-gray-800 py-4 mt-8 shadow-inner">
      <div className="container mx-auto px-4 text-center text-gray-500 text-sm max-w-7xl">
        <p>&copy; {new Date().getFullYear()} Java Test Generator. Powered by Gemini.</p>
      </div>
    </footer>
  );
};
    