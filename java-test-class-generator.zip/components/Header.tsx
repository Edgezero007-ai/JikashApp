
import React from 'react';

interface HeaderProps {
  title: string;
}

export const Header: React.FC<HeaderProps> = ({ title }) => {
  return (
    <header className="bg-gray-800 shadow-md">
      <div className="container mx-auto px-4 py-5 max-w-7xl">
        <h1 className="text-3xl font-bold text-sky-400 text-center">{title}</h1>
        <p className="text-center text-gray-400 mt-1">Generate Java test classes using AI</p>
      </div>
    </header>
  );
};
    