
import React from 'react';

interface RequirementDisplayProps {
  requirements: string;
}

export const RequirementDisplay: React.FC<RequirementDisplayProps> = ({ requirements }) => {
  return (
    <div className="bg-gray-700 p-4 rounded-md max-h-96 overflow-y-auto">
      <pre className="whitespace-pre-wrap text-sm text-gray-300">{requirements}</pre>
    </div>
  );
};
    