
export const APP_TITLE = "Java Test Class Generator";
export const GEMINI_MODEL_NAME = 'gemini-2.5-flash-preview-04-17';

export const REQUIREMENTS_TEXT = `
Project: GcashApp

Modules to test:
- UserAuthentication
- CheckBalance
- CashIn
- CashTransfer
- Transactions

Details:

1.  UserAuthentication:
    *   Parameters: email and password.
    *   Test scenarios:
        *   Valid login: Verify successful authentication (mock database check for credentials).
        *   Invalid login: Verify authentication failure with wrong password or email.

2.  CheckBalance:
    *   Parameters: User ID.
    *   Test scenario: Verify that the balance retrieved for a user ID matches an expected value (mock database or service check).

3.  CashIn:
    *   Test scenario: Verify that a user's balance updates correctly after a cash-in operation.

4.  CashTransfer:
    *   Test scenario: Verify that balances update correctly for both the sender and receiver after a cash transfer.

5.  Transactions:
    *   Test scenario: Verify that transaction records are displayed or retrieved properly, including all necessary details and correct formatting.

General Requirement: All test files should be runnable and designed to pass given appropriate mock implementations for external dependencies.
`;
    