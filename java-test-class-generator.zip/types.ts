
// Currently no global types needed beyond standard React/DOM types.
// This file is kept for future scalability.

export {}; // Ensures this file is treated as a module.
    